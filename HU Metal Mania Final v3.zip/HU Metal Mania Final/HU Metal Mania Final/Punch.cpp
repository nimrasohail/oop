#include "Punch.hpp"
// Punch implementation will go here.
// constructors
#pragma once
#include "game.hpp"
Game temp_obj_3;

Punch::Punch(int x, int y, char tank_pos)
{
    left_or_right = tank_pos;
    // src coorinates from assets.png file, they have been found using spritecow.com
    if (left_or_right == 'l')
    {
        srcRect = {614, 485, 107, 38};
    }
    else if (left_or_right == 'r')
    {
        srcRect = {1626, 64, 192, 60};
    }
    // it will display pigeon on x = x touched point, y = y touched point, the size of pigeon is 50 width, 50 height
    moverRect = {x, y, 100, 40};
}

char Punch::get_tank_char()
{
    return left_or_right;
}

SDL_Rect Punch::getcoords()
{
    return moverRect;
}
// functionalities

void Punch::fly()
{

    if (left_or_right == 'l' && hit == false)
    {
        moverRect.x += 10;
        if (frame == 0)
        { // the initial state of the punch
            srcRect = {614, 485, 107, 38};
            frame++; // the state changes to the next state
        }

        else if (frame == 5)
        { // the second state of the punch
            srcRect = {615, 525, 143, 38};
            frame++; // the state changes to the next state
        }

        else if (frame == 10)
        { // the final state of the punch
            srcRect = {615, 566, 179, 38};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 15)
        { // the final state of the punch
            srcRect = {614, 606, 216, 39};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 20)
        { // the initial state of the punch
            srcRect = {614, 485, 107, 38};
            frame++; // the state changes to the initial state
        }
        else
        {
            frame++;
        }
    }
    else if (left_or_right == 'r' && hit == false)
    {
        moverRect.x -= 10;
        if (frame == 0)
        { // the initial state of the punch
            srcRect = {1626, 64, 192, 60};
            frame++; // the state changes to the next state
        }

        else if (frame == 5)
        { // the second state of the punch
            srcRect = {1566, 131, 251, 60};
            frame++; // the state changes to the next state
        }

        else if (frame == 10)
        { // the final state of the punch
            srcRect = {1509, 197, 308, 60};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 15)
        { // the final state of the punch
            srcRect = {1450, 263, 367, 61};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 20)
        { // the final state of the punch
            srcRect = {1626, 64, 192, 60};
            frame++; // the state is resetted and the process repeats
        }
        else
        {
            frame++;
        }
    }
}

bool Punch::blast_it()
{
    return hit;
}

void Punch::delete_Punch()
{
    if (hit == false)
    {
        temp_obj_3.play_collision_sound();
        hit = true;
        srcRect = {694, 77, 26, 19};
        frame = 6996; // just assigning random frame to start the new animations
    }
    else
    {
        if (frame == 6996)
        { // the final state of the punch
            // frame = 77;
            srcRect = {763, 71, 34, 30};
            frame = 35; // the state is resetted and the process repeats
        }

        else if (frame == 35)
        { // the final state of the punch
            srcRect = {831, 64, 44, 41};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 40)
        { // the final state of the punch
            srcRect = {898, 57, 57, 54};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 45)
        { // the final state of the punch
            srcRect = {968, 59, 63, 58};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 50)
        { // the final state of the punch
            srcRect = {1038, 53, 65, 68};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 55)
        { // the final state of the punch
            srcRect = {1112, 54, 63, 64};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 60)
        { // the final state of the punch
            srcRect = {1194, 64, 46, 50};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 65)
        { // the final state of the punch
            srcRect = {1269, 69, 41, 39};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 70)
        { // the initial state of the punch
            srcRect = {0, 0, 0, 0};
        }
        else
        {
            frame++;
        }
    }
}