#pragma once
#include<SDL.h>
#include "drawing.hpp"
#include<vector>
#include<list>
using namespace std;

class Unit{
    protected:
        SDL_Rect srcRect, moverRect; // declaring attributes of the SDL's

    public:
        // caling the functions created in the cpp file
        Unit(SDL_Rect src, SDL_Rect mover); 
        Unit(SDL_Rect src); 
        Unit();
        void draw();
        virtual void fly();
};