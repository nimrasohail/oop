#include <SDL.h>
#pragma once
#include "drawing.hpp"
#include "Weapons.hpp"

class Punch : public Weapons
{
    // declaring variables
    int frame = 0;
    char left_or_right;
    bool hit = false;

public:
    // calling the constructors, draw and fly functions
    void fly();
    Punch(int x, int y, char tank_pos);
    char get_tank_char();
    SDL_Rect getcoords();
    void delete_Punch();
    bool blast_it();
};
