#include "Bullets.hpp"
// Missile implementation will go here.
// constructors
#pragma once
#include "game.hpp"
Game temp_obj;

Bullets::Bullets(int x, int y, char tank_pos)
{
    left_or_right = tank_pos;
    // src coorinates from assets.png file, they have been found using spritecow.com
    if (left_or_right == 'l')
    {
        srcRect = {819, 268, 42, 36};
    }
    else if (left_or_right == 'r')
    {
        srcRect = {986, 374, 43, 36};
    }
    // it will display pigeon on x = x touched point, y = y touched point, the size of pigeon is 50 width, 50 height
    moverRect = {x, y, 100, 40};
}

SDL_Rect Bullets::getcoords()
{
    return moverRect;
}
// functionalities

char Bullets::get_tank_char()
{
    return left_or_right;
}

bool Bullets::blast_it()
{
    return hit;
}

void Bullets::delete_bullet()
{
    if (hit == false)
    {
        temp_obj.play_collision_sound();
        hit = true;
        srcRect = {898, 57, 57, 54};
    }
    else
    {
        if (frame == 30)
        { // the final state of the punch
            // frame = 77;
            srcRect = {763, 71, 34, 30};
            frame = 35; // the state is resetted and the process repeats
        }

        else if (frame == 35)
        { // the final state of the punch
            srcRect = {831, 64, 44, 41};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 40)
        { // the final state of the punch
            srcRect = {898, 57, 57, 54};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 45)
        { // the final state of the punch
            srcRect = {968, 59, 63, 58};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 50)
        { // the final state of the punch
            srcRect = {1038, 53, 65, 68};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 55)
        { // the final state of the punch
            srcRect = {1112, 54, 63, 64};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 60)
        { // the final state of the punch
            srcRect = {1194, 64, 46, 50};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 65)
        { // the final state of the punch
            srcRect = {1269, 69, 41, 39};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 70)
        { // the initial state of the punch
            srcRect = {0, 0, 0, 0};
        }
        else
        {
            frame++;
        }
    }
}

void Bullets::fly()
{

    if (left_or_right == 'l' && hit == false)
    {
        moverRect.x += 7;
        if (frame == 0)
        { // the initial state of the punch
            srcRect = {819, 268, 42, 36};
            frame++; // the state changes to the next state
        }

        else if (frame == 5)
        { // the second state of the punch
            srcRect = {950, 267, 44, 38};
            frame++; // the state changes to the next state
        }

        else if (frame == 10)
        { // the final state of the punch
            srcRect = {1000, 271, 38, 30};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 15)
        { // the final state of the punch
            srcRect = {1051, 274, 31, 23};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 20)
        { // the final state of the punch
            srcRect = {1103, 278, 23, 15};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 25)
        { // the final state of the punch
            srcRect = {1151, 281, 19, 10};
            frame++; // the state is resetted and the process repeats
        }
        else
        {
            frame++;
        }
    }

    if (left_or_right == 'r' && hit == false)
    {
        moverRect.x -= 7;
        if (frame == 0)
        { // the initial state of the punch
            srcRect = {986, 374, 43, 36};
            frame++; // the state changes to the next state
        }

        else if (frame == 5)
        { // the second state of the punch
            srcRect = {853, 373, 44, 38};
            frame++; // the state changes to the next state
        }

        else if (frame == 10)
        { // the final state of the punch
            srcRect = {809, 376, 38, 31};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 15)
        { // the final state of the punch
            srcRect = {765, 381, 31, 23};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 20)
        { // the final state of the punch
            srcRect = {721, 385, 23, 15};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 25)
        { // the final state of the punch
            srcRect = {677, 387, 19, 11};
            frame++; // the state is resetted and the process repeats
        }
        else
        {
            frame++;
        }
    }
}