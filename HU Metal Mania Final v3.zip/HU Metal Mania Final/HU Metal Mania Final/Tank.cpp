#include "Tank.hpp"
#pragma once
// Tank implementation will go here.

void Tank::fly(SDL_Keycode key, int tank_no)
{

    if (key == SDLK_d && tank_no == 0)
    {
        if (frame == 0)
        {                                         // used the logic mod counter%3==0 so first image of pigeon should appear
            SDL_Rect values = {47, 477, 125, 93}; // sprite cow values
            srcRect = values;                     // calling helper function to update the srcRect
            frame = 1;                            // setting the counter equal to 0 so that counter don't updated indefinitely
        }
        else if (frame == 1)
        {
            SDL_Rect values = {174, 476, 125, 94}; // second image of the pigeon so that it appears as if it is flying
            srcRect = values;                      // updating values
            frame = 2;
        }
        else if (frame == 2)
        {
            SDL_Rect values = {301, 476, 125, 94}; // third image of the pigeon
            srcRect = values;                      // updating values
            frame = 3;
        }

        else if (frame == 3)
        {
            SDL_Rect values = {428, 476, 125, 94}; // third image of the pigeon
            srcRect = values;                      // updating values
            frame = 4;
        }

        else if (frame == 4)
        {
            SDL_Rect values = {47, 477, 125, 93}; // third image of the pigeon
            srcRect = values;                     // updating values
            frame = 0;
        }

        if (moverRect.x >= 800)
        { // for tanks to stay on screen
            moverRect.x -= 2;
        }

        moverRect.x += 2; // dition that if pigeon greater than 1000 so set moverRect.x =0 or update to +5
    }

    if (key == SDLK_a && tank_no == 0)
    {
        if (frame == 0)
        {                                          // used the logic mod counter%3==0 so first image of pigeon should appear
            SDL_Rect values = {428, 476, 125, 94}; // sprite cow values
            srcRect = values;                      // calling helper function to update the srcRect
            frame = 1;                             // setting the counter equal to 0 so that counter don't updated indefinitely
        }
        else if (frame == 1)
        {
            SDL_Rect values = {301, 476, 125, 94}; // second image of the pigeon so that it appears as if it is flying
            srcRect = values;                      // updating values
            frame = 2;
        }
        else if (frame == 2)
        {
            SDL_Rect values = {174, 476, 125, 94}; // third image of the pigeon
            srcRect = values;                      // updating values
            frame = 3;
        }

        else if (frame == 3)
        {
            SDL_Rect values = {47, 477, 125, 93}; // third image of the pigeon
            srcRect = values;                     // updating values
            frame = 4;
        }

        else if (frame == 4)
        {
            SDL_Rect values = {428, 476, 125, 94}; // third image of the pigeon
            srcRect = values;                      // updating values
            frame = 0;
        }

        if (moverRect.x < 0)
        { // for tanks to stay on screen
            moverRect.x += 2;
        }

        moverRect.x -= 2; // to move the object in the right direction
        //} // checking the condition that if pigeon greater than 1000 so set moverRect.x =0 or update to +5
    }

    if (key == SDLK_LEFT && tank_no == 1)
    {
        if (frame == 0)
        {                                            // used the logic mod counter%3==0 so first image of pigeon should appear
            SDL_Rect values = {1886, 543, 257, 161}; // sprite cow values
            srcRect = values;                        // calling helper function to update the srcRect
            frame = 1;                               // setting the counter equal to 0 so that counter don't updated indefinitely
        }
        else if (frame == 1)
        {
            SDL_Rect values = {1886, 737, 257, 161}; // second image of the pigeon so that it appears as if it is flying
            srcRect = values;                        // updating values
            frame = 2;
        }
        else if (frame == 2)
        {
            SDL_Rect values = {1886, 931, 257, 161}; // third image of the pigeon
            srcRect = values;                        // updating values
            frame = 3;
        }

        else if (frame == 3)
        {
            SDL_Rect values = {1886, 1126, 257, 161}; // third image of the pigeon
            srcRect = values;                         // updating values
            frame = 4;
        }

        else if (frame == 4)
        {
            SDL_Rect values = {1886, 543, 257, 161}; // third image of the pigeon
            srcRect = values;                        // updating values
            frame = 0;
        }

        if (moverRect.x < 0)
        { // for tanks to stay on screen
            moverRect.x += 5;
        }

        moverRect.x -= 5; // to move the object in the left direction
    }

    if (key == SDLK_RIGHT && tank_no == 1)
    {
        if (frame == 0)
        {                                            // used the logic mod counter%3==0 so first image of pigeon should appear
            SDL_Rect values = {1886, 543, 257, 161}; // sprite cow values
            srcRect = values;                        // calling helper function to update the srcRect
            frame = 1;                               // setting the counter equal to 0 so that counter don't updated indefinitely
        }
        else if (frame == 1)
        {
            SDL_Rect values = {1886, 1126, 257, 161}; // second image of the pigeon so that it appears as if it is flying
            srcRect = values;                         // updating values
            frame = 2;
        }
        else if (frame == 2)
        {
            SDL_Rect values = {1886, 931, 257, 161}; // third image of the pigeon
            srcRect = values;                        // updating values
            frame = 3;
        }

        else if (frame == 3)
        {
            SDL_Rect values = {1886, 737, 257, 161}; // third image of the pigeon
            srcRect = values;                        // updating values
            frame = 4;
        }

        else if (frame == 4)
        {
            SDL_Rect values = {1886, 543, 257, 161}; // third image of the pigeon
            srcRect = values;                        // updating values
            frame = 0;
        }

        if (moverRect.x + moverRect.w >= 1000)
        { // for tanks to stay on screen
            moverRect.x -= 5;
        }

        moverRect.x += 5; // dition that if pigeon greater than 1000 so set moverRect.x =0 or update to +5
    }
}

SDL_Rect Tank::getcoords()
{
    return moverRect;
}

Tank::Tank() : Unit()
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {27, 457, 125, 93};

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {30, 40, 200, 120};
}
Tank::Tank(int x, int y) : Unit()
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {27, 457, 125, 93};

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {x, y, 200, 120};
    frame = 1;
}

Tank::Tank(int tank_no, SDL_Rect srcRect1, int x, int y)
{
    srcRect = srcRect1;

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    if (tank_no == 0)
        moverRect = {x, y, 250, 200};
    else if (tank_no == 1)
        moverRect = {x, y, 300, 200};
    frame = 1;
}