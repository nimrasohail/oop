#include <SDL.h>
#pragma once
#include "drawing.hpp"
#include "Weapons.hpp"

class Missile : public Weapons
{
    // declaring variables
    int frame = 0;
    char left_or_right;
    bool hit = false;

public:
    // calling the constructors, draw and fly functions
    void fly();
    Missile(int x, int y, char tank_pos);
    SDL_Rect getcoords();
    void delete_missile();
    char get_tank_char();
    bool blast_it();
};
