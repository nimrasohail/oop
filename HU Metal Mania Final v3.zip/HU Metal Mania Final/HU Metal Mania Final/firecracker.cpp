#include "firecracker.hpp"
// firecracker implementation will go here.
#include "drawing.hpp"
#pragma once
#include "game.hpp"
Game temp_obj_1;

bool firecracker::blast_it()
{
    return hit;
}

SDL_Rect firecracker::getcoords()
{
    return moverRect;
}

void firecracker::delete_firecracker(int x, int y)
{
    moverRect = {x, y, 150, 150};
    if (hit == false)
    {
        temp_obj_1.play_collision_sound();
        hit = true;
        srcRect = {227, 1301, 123, 134};
    }
    else
    {
        if (frame == 0)
        { // the final state of the punch
            srcRect = {404, 1267, 165, 180};
            frame += 1; // the state is resetted and the process repeats
        }

        else if (frame == 10)
        { // the final state of the punch
            srcRect = {11, 1470, 181, 178};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 20)
        { // the initial state of the punch
            srcRect = {0, 0, 0, 0};
        }
        else
        {
            frame++;
        }
    }
}

void firecracker::fly()
{

    moverRect.y += 2;
}

firecracker::firecracker()
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {1238, 485, 40, 20};

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {30, 40, 40, 20};
}

firecracker::firecracker(int x, int y)
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {1238, 485, 40, 50};

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {x, y, 40, 20};
    // frame=1;   // setting the frame to 1 so that it dont cause the delay
}
