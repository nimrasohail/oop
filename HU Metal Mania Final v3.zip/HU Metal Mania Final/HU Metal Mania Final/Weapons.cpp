#include "Weapons.hpp"
#pragma once 

Weapons::Weapons():Unit(){};

Weapons::Weapons(SDL_Rect src_, SDL_Rect mover_):Unit(src_,mover_){};
