#include "Unit.hpp"
#include "drawing.hpp"
#include<SDL.h>
#pragma once 

class TNT: public Unit{
    int frame = 0;
    bool hit = false;
public:
    // add the fly function here as well.
    void fly();
    SDL_Rect getcoords();
    void delete_TNT(int,int);
    TNT(); 
    TNT(int x, int y);   // constructors 
    bool blast_it();
};