#include <SDL.h>
#include "Tank.hpp"
#include "firecracker.hpp"
#include "Punch.hpp"
#include "Missile.hpp"
#include "Crow.hpp"
#include "Bullets.hpp"
#include "TNT.hpp"
#include "life.hpp"
#include "Weapons.hpp"
#include <vector>
#include <list>
#pragma once
using namespace std;

class HUMania
{
    vector<Tank *> tanks; // pigeon vector dynamic
    vector<firecracker *> firecrack;
    vector<Punch *> punches;
    vector<Missile *> missiles;
    vector<Bullets *> bullets;
    // vector<Weapons *> weapons;
    vector<TNT *> TNTs;
    vector<life *> heart;
    vector<Crow *> crows;

public:
    // void update_screen();
    void drawObjects();
    void createObject(int, int);
    void createPunch(int, int, char);
    void createMissile(int, int, char);
    void createBullets(int, int, char);
    void update(SDL_Renderer *gRenderer, SDL_Texture *assets);
    void moveWarrior(SDL_Renderer *gRenderer, SDL_Texture *assets, SDL_Keycode key);
    void initialize();
    SDL_Rect get_tank_coords(int tank_no);
    // Pigeon* get();
    // Pigeon get_right_tank();
    void detect_collision_missiles(SDL_Rect, char);
    bool detect_collision_TNT(SDL_Rect);
    bool detect_collision_firecracker(SDL_Rect);
    void detect_collision_punches(SDL_Rect, char);
    void detect_collision_fire(SDL_Rect, char);
    void detect_heart(char, int);
    SDL_Rect get_missile_coords(int tank_no);

    ~HUMania(); // destroyer
};