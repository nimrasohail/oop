#include <SDL.h>
#include "Weapons.hpp"
#include "drawing.hpp"
#pragma once
// #include "HUMania.hpp"
class Bullets : public Weapons
{
    // declaring variables
    int frame = 0;
    char left_or_right;
    bool hit = false;

public:
    // calling the constructors, draw and fly functions
    void fly();
    Bullets(int x, int y, char tank_pos);
    SDL_Rect getcoords();
    void delete_bullet();
    char get_tank_char();
    bool blast_it();
};
