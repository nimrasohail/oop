#include<SDL.h>
#include "drawing.hpp"
#include "Unit.hpp"
#pragma once 

class Tank: public Unit{
    int frame = 0;

public:
    // add the fly function here as well.
    void fly(SDL_Keycode key,int tank_no);

    Tank();            // overloaded constructors 
    Tank(int x, int y);
    Tank(int tank_no,SDL_Rect srcRect1, int x, int y);
    // may add other overloaded constructors here... 
    int get_x();
    int get_y();
    SDL_Rect getcoords();
    
};
