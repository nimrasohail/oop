#include "Unit.hpp"
#include "drawing.hpp"
#include<SDL.h>
#pragma once 

class firecracker: public Unit{

    int frame = 0;
    bool hit = false;
public:
    // add the fly function here as well.
    void fly();
    SDL_Rect getcoords();
    void delete_firecracker(int, int);
    firecracker(); 
    firecracker(int x, int y);   // constructors 
    // may add other overloaded constructors here... 
    bool blast_it();
};