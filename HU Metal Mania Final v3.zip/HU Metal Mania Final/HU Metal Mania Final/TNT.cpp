#include "TNT.hpp"
// firecracker implementation will go here.
#include "drawing.hpp"
#pragma once
#include "game.hpp"
Game temp_obj_4;

SDL_Rect TNT::getcoords()
{
    return moverRect;
}

bool TNT::blast_it()
{
    return hit;
}

void TNT::delete_TNT(int x, int y)
{
    moverRect = {x, y, 150, 150};
    if (hit == false)
    {
        temp_obj_4.play_collision_sound();
        hit = true;
        srcRect = {227, 1301, 123, 134};
    }
    else
    {
        if (frame == 0)
        { // the final state of the punch
            srcRect = {404, 1267, 165, 180};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 10)
        { // the final state of the punch
            srcRect = {11, 1470, 181, 178};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 20)
        { // the initial state of the punch
            srcRect = {0, 0, 0, 0};
            // hit=false;
        }
        else
        {
            frame++;
        }
    }
}

void TNT::fly()
{
    // used the logic mod counter%3==0 so first image of bee should appear
    // SDL_Rect values = {1228,475,40,50};   // sprite cow values
    // srcRect = values;
    // moverRect.x-=10;
    moverRect.y += 2;
}

TNT::TNT()
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {1143, 497, 85, 32};

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {30, 40, 40, 20};
}

TNT::TNT(int x, int y)
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {1143, 497, 85, 32};

    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 60 height
    moverRect = {x, y, 40, 20};
    // frame=1;   // setting the frame to 1 so that it dont cause the delay
}
