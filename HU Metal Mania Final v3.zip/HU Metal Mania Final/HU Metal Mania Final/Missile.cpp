#include "Missile.hpp"
#include "game.hpp"
// Missile implementation will go here.
// constructors
#pragma once
Game temp_obj_2;

Missile::Missile(int x, int y, char tank_pos)
{
    left_or_right = tank_pos;
    // src coorinates from assets.png file, they have been found using spritecow.com
    if (left_or_right == 'l')
    {
        srcRect = {1618, 373, 49, 17};
    }
    else if (left_or_right == 'r')
    {
        srcRect = {1421, 373, 48, 17};
    }
    // it will display pigeon on x = x touched point, y = y touched point, the size of pigeon is 50 width, 50 height
    moverRect = {x, y, 100, 40};
}

SDL_Rect Missile::getcoords()
{
    return moverRect;
}
// functionalities
bool Missile::blast_it()
{
    return hit;
}

char Missile::get_tank_char()
{
    return left_or_right;
}

void Missile::delete_missile()
{
    if (hit == false)
    {
        temp_obj_2.play_collision_sound();
        hit = true;
        srcRect = {898, 57, 57, 54};
        frame = 0;
    }
    else
    {
        if (frame == 0)
        { // the final state of the punch
            // frame = 77;
            srcRect = {763, 71, 34, 30};
            frame = 35; // the state is resetted and the process repeats
        }

        else if (frame == 35)
        { // the final state of the punch
            srcRect = {831, 64, 44, 41};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 40)
        { // the final state of the punch
            srcRect = {898, 57, 57, 54};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 45)
        { // the final state of the punch
            srcRect = {968, 59, 63, 58};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 50)
        { // the final state of the punch
            srcRect = {1038, 53, 65, 68};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 55)
        { // the final state of the punch
            srcRect = {1112, 54, 63, 64};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 60)
        { // the final state of the punch
            srcRect = {1194, 64, 46, 50};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 65)
        { // the final state of the punch
            srcRect = {1269, 69, 41, 39};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 70)
        { // the initial state of the punch
            srcRect = {0, 0, 0, 0};
        }
        else
        {
            frame++;
        }
    }
}

void Missile::fly()
{

    if (left_or_right == 'l' && hit == false)
    {
        moverRect.x += 7;
        if (frame == 5)
        { // the initial state of the punch
            srcRect = {1618, 373, 49, 17};
            frame++; // the state changes to the next state
        }

        else if (frame == 10)
        { // the second state of the punch
            srcRect = {1605, 405, 62, 22};
            frame++; // the state changes to the next state
        }

        else if (frame == 15)
        { // the final state of the punch
            srcRect = {1577, 435, 92, 40};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 20)
        { // the final state of the punch
            srcRect = {1573, 488, 97, 21};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 25)
        { // the final state of the punch
            srcRect = {1570, 539, 101, 21};
            frame++; // the state is resetted and the process repeats
        }
        else if (frame == 30)
        { // the final state of the punch
            srcRect = {1564, 589, 109, 18};
            frame++; // the state is resetted and the process repeats
        }
        else
        {
            frame++;
        }
    }

    if (left_or_right == 'r' && hit == false)
    {
        moverRect.x -= 7;
        if (frame == 5)
        { // the initial state of the punch
            srcRect = {1421, 373, 48, 17};
            frame++; // the state changes to the next state
        }

        else if (frame == 10)
        { // the second state of the punch
            srcRect = {1421, 405, 62, 22};
            frame++; // the state changes to the next state
        }

        else if (frame == 15)
        { // the final state of the punch
            srcRect = {1419, 435, 92, 40};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 20)
        { // the final state of the punch
            srcRect = {1418, 488, 97, 21};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 25)
        { // the final state of the punch
            srcRect = {1417, 540, 101, 20};
            frame++; // the state is resetted and the process repeats
        }

        else if (frame == 30)
        { // the final state of the punch
            srcRect = {1416, 590, 108, 17};
            frame++; // the state is resetted and the process repeats
        }
        else
        {
            frame++;
        }
    }
}