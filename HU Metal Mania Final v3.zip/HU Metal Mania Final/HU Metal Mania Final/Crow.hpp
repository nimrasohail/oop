#include<SDL.h>
#include "drawing.hpp"
#pragma once 
class Crow{
    // declaring variables
    SDL_Rect srcRect, moverRect;
    int frame = 0;

    public:
        // calling the constructors, draw and fly functions
        void draw();
        void fly();
        Crow();
        Crow(int x, int y); 
};
